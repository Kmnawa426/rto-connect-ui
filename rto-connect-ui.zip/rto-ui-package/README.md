# RTO Connect static UI pages

A responsive, multi-page HTML/CSS UI template for an RTO driving licence portal. Includes dashboard, services, application forms, application tracking, training, driving test, fines/e-challans, notifications, login, registration, and driving-school registration.

## Run locally
Open `index.html` in a browser. Shared styling is in `css/style.css`. No JavaScript is included; forms, file uploads, payments, and navigation actions are static visual placeholders.

## Pages
`index.html`, `services.html`, `apply.html`, `apply-licence.html`, `applications.html`, `training.html`, `driving-test.html`, `fines.html`, `notifications.html`, `login.html`, `register.html`, `school-register.html`.
