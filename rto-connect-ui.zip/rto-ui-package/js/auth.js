/**
 * RTO Connect - Client-Side Authentication & Validation
 * Handles Login, Registration, and Password Utilities (No backend required)
 */

(function () {
  'use strict';

  const STORAGE_KEY_REGISTERED = 'rto_registered_users';

  // Helper: Retrieve registered users list from localStorage
  function getRegisteredUsers() {
    const list = localStorage.getItem(STORAGE_KEY_REGISTERED);
    if (list) {
      try {
        return JSON.parse(list);
      } catch (e) {
        return [];
      }
    }
    return [
      {
        name: 'Km Nawaz',
        email: 'kmnawa0@gmail.com',
        phone: '9876543210',
        password: 'Password123'
      }
    ];
  }

  function saveRegisteredUser(user) {
    const users = getRegisteredUsers();
    users.push(user);
    localStorage.setItem(STORAGE_KEY_REGISTERED, JSON.stringify(users));
  }

  // --- Password Show/Hide Toggle Button ---
  function initPasswordToggles() {
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
      // Avoid duplicate wrappers
      if (input.dataset.hasToggle) return;
      input.dataset.hasToggle = 'true';

      const wrapper = document.createElement('div');
      wrapper.className = 'password-field-wrap';
      input.parentNode.insertBefore(wrapper, input);
      wrapper.appendChild(input);

      const toggleBtn = document.createElement('button');
      toggleBtn.type = 'button';
      toggleBtn.className = 'btn-toggle-password';
      toggleBtn.setAttribute('aria-label', 'Toggle password visibility');
      toggleBtn.innerHTML = '👁';

      toggleBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (input.type === 'password') {
          input.type = 'text';
          toggleBtn.innerHTML = '✕';
          toggleBtn.title = 'Hide password';
        } else {
          input.type = 'password';
          toggleBtn.innerHTML = '👁';
          toggleBtn.title = 'Show password';
        }
      });

      wrapper.appendChild(toggleBtn);
    });
  }

  // --- Login Page Logic ---
  function initLoginPage() {
    const loginCard = document.querySelector('.auth-card');
    if (!loginCard) return;

    const isLogin = window.location.pathname.includes('login.html') || document.title.toLowerCase().includes('sign in');
    if (!isLogin) return;

    const form = loginCard.querySelector('form');
    if (!form) return;

    const identifierInput = form.querySelector('input:not([type="password"])');
    const passwordInput = form.querySelector('input[type="password"]');
    const submitBtn = form.querySelector('button');
    const forgotLink = form.querySelector('a[href="#"], a[href*="forgot"]');

    if (forgotLink) {
      forgotLink.addEventListener('click', function (e) {
        e.preventDefault();
        const email = prompt('Enter your registered email address to receive password reset instructions:');
        if (email && email.trim()) {
          if (window.RTO && window.RTO.showToast) {
            window.RTO.showToast(`Password reset link sent to ${email.trim()} (simulated).`, 'success');
          } else {
            alert(`Password reset link sent to ${email.trim()} (simulated).`);
          }
        }
      });
    }

    if (submitBtn) {
      submitBtn.addEventListener('click', function (e) {
        e.preventDefault();
        clearErrors(form);

        const identifier = identifierInput ? identifierInput.value.trim() : '';
        const password = passwordInput ? passwordInput.value : '';

        let hasError = false;

        if (!identifier) {
          showFieldError(identifierInput, 'Please enter your email or mobile number.');
          hasError = true;
        }

        if (!password) {
          showFieldError(passwordInput, 'Please enter your password.');
          hasError = true;
        } else if (password.length < 4) {
          showFieldError(passwordInput, 'Password must be at least 4 characters.');
          hasError = true;
        }

        if (hasError) return;

        // Simulate authentication
        submitBtn.disabled = true;
        submitBtn.textContent = 'Verifying credentials...';

        setTimeout(() => {
          // Check registered users or construct session
          const users = getRegisteredUsers();
          const matched = users.find(u => 
            (u.email.toLowerCase() === identifier.toLowerCase() || u.phone === identifier)
          );

          let userSession;
          if (matched) {
            userSession = {
              name: matched.name,
              email: matched.email,
              phone: matched.phone || '',
              role: 'Applicant account',
              initials: getInitials(matched.name)
            };
          } else {
            // Friendly fallback: allow sign-in with entered identifier
            const inferredName = identifier.includes('@') ? identifier.split('@')[0] : 'Km Nawaz';
            userSession = {
              name: inferredName.charAt(0).toUpperCase() + inferredName.slice(1),
              email: identifier.includes('@') ? identifier : 'user@rtoconnect.in',
              phone: !identifier.includes('@') ? identifier : '',
              role: 'Applicant account',
              initials: getInitials(inferredName)
            };
          }

          if (window.RTO && window.RTO.setCurrentUser) {
            window.RTO.setCurrentUser(userSession);
            window.RTO.showToast(`Welcome back, ${userSession.name}!`, 'success');
          }

          submitBtn.textContent = 'Signed in ✓';
          setTimeout(() => {
            window.location.href = 'index.html';
          }, 800);
        }, 700);
      });
    }
  }

  // --- Registration Page Logic ---
  function initRegisterPage() {
    const isRegister = window.location.pathname.includes('register.html') || document.title.toLowerCase().includes('create account');
    if (!isRegister) return;

    const authCard = document.querySelector('.auth-card');
    if (!authCard) return;

    const form = authCard.querySelector('form');
    if (!form) return;

    const nameInput = form.querySelector('input[placeholder*="name" i], input[placeholder*="identity" i]');
    const emailInput = form.querySelector('input[type="email"]');
    const phoneInput = form.querySelector('input[type="tel"]');
    const passwordInput = form.querySelector('input[type="password"]');
    const submitBtn = form.querySelector('button');

    if (submitBtn) {
      submitBtn.addEventListener('click', function (e) {
        e.preventDefault();
        clearErrors(form);

        const name = nameInput ? nameInput.value.trim() : '';
        const email = emailInput ? emailInput.value.trim() : '';
        const phone = phoneInput ? phoneInput.value.trim() : '';
        const password = passwordInput ? passwordInput.value : '';

        let hasError = false;

        if (!name || name.length < 2) {
          showFieldError(nameInput, 'Please enter your full name as on identity proof.');
          hasError = true;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || !emailRegex.test(email)) {
          showFieldError(emailInput, 'Please enter a valid email address.');
          hasError = true;
        }

        const cleanPhone = phone.replace(/\D/g, '');
        if (!phone || cleanPhone.length < 10) {
          showFieldError(phoneInput, 'Please enter a valid 10-digit mobile number.');
          hasError = true;
        }

        if (!password || password.length < 6) {
          showFieldError(passwordInput, 'Password must be at least 6 characters.');
          hasError = true;
        }

        if (hasError) return;

        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating account...';

        setTimeout(() => {
          const newUser = {
            name: name,
            email: email,
            phone: cleanPhone,
            password: password,
            role: 'Applicant account',
            initials: getInitials(name)
          };

          saveRegisteredUser(newUser);

          if (window.RTO && window.RTO.setCurrentUser) {
            window.RTO.setCurrentUser(newUser);
            window.RTO.showToast(`Account created! Welcome, ${newUser.name}.`, 'success');
          }

          submitBtn.textContent = 'Account created ✓';
          setTimeout(() => {
            window.location.href = 'index.html';
          }, 900);
        }, 750);
      });
    }
  }

  // --- Error Presentation Helpers ---
  function showFieldError(inputElem, message) {
    if (!inputElem) return;
    inputElem.classList.add('input-error');
    const parentField = inputElem.closest('.field') || inputElem.parentNode;
    
    // Check if error span already exists
    let errorSpan = parentField.querySelector('.field-error-msg');
    if (!errorSpan) {
      errorSpan = document.createElement('span');
      errorSpan.className = 'field-error-msg';
      parentField.appendChild(errorSpan);
    }
    errorSpan.textContent = message;
    inputElem.focus();
  }

  function clearErrors(formElem) {
    formElem.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));
    formElem.querySelectorAll('.field-error-msg').forEach(el => el.remove());
  }

  function getInitials(name) {
    if (!name) return 'U';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  document.addEventListener('DOMContentLoaded', function () {
    initPasswordToggles();
    initLoginPage();
    initRegisterPage();
  });
})();
