/**
 * RTO Connect - Client-side UI & Interactions
 * Vanilla JavaScript (No server required)
 */

(function () {
  'use strict';

  // --- Session Management (Client-side localStorage) ---
  const STORAGE_KEY_USER = 'rto_connect_user';
  const DEFAULT_USER = {
    name: 'Km Nawaz',
    email: 'kmnawa0@gmail.com',
    phone: '9876543210',
    role: 'Applicant account',
    initials: 'KN'
  };

  function getCurrentUser() {
    const stored = localStorage.getItem(STORAGE_KEY_USER);
    if (stored === 'guest') return null;
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        return DEFAULT_USER;
      }
    }
    // Default to mock logged-in user on first visit
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(DEFAULT_USER));
    return DEFAULT_USER;
  }

  function setCurrentUser(user) {
    if (!user) {
      localStorage.setItem(STORAGE_KEY_USER, 'guest');
    } else {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    }
    updateHeaderProfile();
  }

  function logoutUser() {
    setCurrentUser(null);
    showToast('Signed out successfully', 'info');
    setTimeout(() => {
      // If currently on an auth-only page, redirect to index.html or login.html
      const page = window.location.pathname.split('/').pop() || 'index.html';
      if (page === 'applications.html' || page === 'apply.html' || page === 'apply-licence.html') {
        window.location.href = 'login.html';
      } else {
        updateHeaderProfile();
      }
    }, 600);
  }

  // --- Global Toast Notifications ---
  function showToast(message, type = 'info', duration = 3500) {
    let container = document.getElementById('rto-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'rto-toast-container';
      container.className = 'rto-toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `rto-toast rto-toast-${type}`;
    
    let icon = 'ℹ';
    if (type === 'success') icon = '✓';
    if (type === 'error') icon = '⚠';

    toast.innerHTML = `
      <span class="rto-toast-icon">${icon}</span>
      <span class="rto-toast-msg">${message}</span>
      <button type="button" class="rto-toast-close" aria-label="Close">&times;</button>
    `;

    toast.querySelector('.rto-toast-close').addEventListener('click', () => {
      toast.classList.add('rto-toast-fade');
      setTimeout(() => toast.remove(), 250);
    });

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentNode) {
        toast.classList.add('rto-toast-fade');
        setTimeout(() => toast.remove(), 250);
      }
    }, duration);
  }

  // --- Header & User Dropdown Initialization ---
  function updateHeaderProfile() {
    const profileWrap = document.querySelector('.header .profile');
    if (!profileWrap) return;

    const user = getCurrentUser();

    if (!user) {
      // Guest state: show Sign In & Register buttons
      profileWrap.className = 'profile profile-guest';
      profileWrap.innerHTML = `
        <div class="guest-actions">
          <a href="login.html" class="btn btn-outline btn-sm">Sign in</a>
          <a href="register.html" class="btn btn-primary btn-sm">Register</a>
        </div>
      `;
      return;
    }

    // Logged-in state: show avatar and interactive dropdown toggle
    profileWrap.className = 'profile profile-user';
    profileWrap.innerHTML = `
      <button type="button" class="profile-trigger" id="profileDropdownBtn" aria-expanded="false" aria-haspopup="true">
        <span class="avatar">${user.initials || 'U'}</span>
        <span class="profile-meta">
          <strong>${user.name}</strong>
          <small>${user.role || 'Applicant'}</small>
        </span>
        <span class="chevron-arrow">▾</span>
      </button>
      <div class="dropdown-menu" id="userDropdownMenu" role="menu">
        <div class="dropdown-header">
          <span class="avatar avatar-lg">${user.initials || 'U'}</span>
          <div>
            <div class="user-fullname">${user.name}</div>
            <div class="user-email">${user.email}</div>
          </div>
        </div>
        <div class="dropdown-divider"></div>
        <a href="index.html" class="dropdown-item" role="menuitem">
          <span class="dropdown-icon">▦</span> Overview Dashboard
        </a>
        <a href="applications.html" class="dropdown-item" role="menuitem">
          <span class="dropdown-icon">▤</span> My Applications
        </a>
        <a href="training.html" class="dropdown-item" role="menuitem">
          <span class="dropdown-icon">✓</span> Training & Progress
        </a>
        <a href="fines.html" class="dropdown-item" role="menuitem">
          <span class="dropdown-icon">₹</span> Fines & e-Challans
        </a>
        <a href="notifications.html" class="dropdown-item" role="menuitem">
          <span class="dropdown-icon">🔔</span> Notifications
        </a>
        <div class="dropdown-divider"></div>
        <button type="button" class="dropdown-item dropdown-logout" id="logoutBtn" role="menuitem">
          <span class="dropdown-icon">↪</span> Sign out
        </button>
      </div>
    `;

    // Dropdown toggle logic
    const triggerBtn = document.getElementById('profileDropdownBtn');
    const dropdown = document.getElementById('userDropdownMenu');
    const logoutBtn = document.getElementById('logoutBtn');

    if (triggerBtn && dropdown) {
      triggerBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        const isOpen = dropdown.classList.contains('show');
        closeAllDropdowns();
        if (!isOpen) {
          dropdown.classList.add('show');
          triggerBtn.setAttribute('aria-expanded', 'true');
        }
      });
    }

    if (logoutBtn) {
      logoutBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        closeAllDropdowns();
        logoutUser();
      });
    }
  }

  function closeAllDropdowns() {
    document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
      menu.classList.remove('show');
    });
    document.querySelectorAll('.profile-trigger[aria-expanded="true"]').forEach(btn => {
      btn.setAttribute('aria-expanded', 'false');
    });
  }

  // --- Mobile Hamburger Menu ---
  function initMobileMenu() {
    const headerInner = document.querySelector('.header-inner');
    const nav = document.querySelector('.nav');
    if (!headerInner || !nav) return;

    // Check if toggle button already exists
    if (headerInner.querySelector('.mobile-nav-toggle')) return;

    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'mobile-nav-toggle';
    toggleBtn.setAttribute('aria-label', 'Toggle navigation menu');
    toggleBtn.innerHTML = '<span class="hamburger-bar"></span><span class="hamburger-bar"></span><span class="hamburger-bar"></span>';

    headerInner.insertBefore(toggleBtn, nav);

    toggleBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      nav.classList.toggle('nav-open');
      toggleBtn.classList.toggle('active');
    });

    // Close nav when clicking outside
    document.addEventListener('click', function (e) {
      if (!nav.contains(e.target) && !toggleBtn.contains(e.target)) {
        nav.classList.remove('nav-open');
        toggleBtn.classList.remove('active');
      }
    });
  }

  // --- Active Nav Link Highlighter ---
  function highlightActiveNav() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav a');
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href === currentPage || (currentPage === '' && href === 'index.html')) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  // --- Page Interactions (Challan payments, forms, tabs) ---
  function initPageInteractions() {
    // 1. Fines payment simulation (fines.html)
    const challanRows = document.querySelectorAll('table tbody tr');
    challanRows.forEach(row => {
      const statusBadge = row.querySelector('.badge-red');
      if (statusBadge && statusBadge.textContent.trim().toLowerCase() === 'unpaid') {
        // Add a Pay button if not already present
        const actionCell = row.cells[row.cells.length - 1];
        if (actionCell && !actionCell.querySelector('.btn-pay-challan')) {
          const payBtn = document.createElement('button');
          payBtn.type = 'button';
          payBtn.className = 'btn btn-primary btn-xs btn-pay-challan';
          payBtn.style.marginLeft = '8px';
          payBtn.textContent = 'Pay now';
          payBtn.addEventListener('click', function () {
            if (confirm('Proceed to simulate instant payment for this challan?')) {
              statusBadge.className = 'badge badge-green';
              statusBadge.textContent = 'Paid';
              payBtn.remove();
              showToast('Challan payment simulated successfully! Receipt generated.', 'success');
              
              // Update outstanding stat if present
              const statVals = document.querySelectorAll('.stats .stat strong');
              if (statVals.length >= 2) {
                statVals[0].textContent = '₹0';
                statVals[1].textContent = '00';
              }
            }
          });
          actionCell.appendChild(payBtn);
        }
      }
    });

    // 2. Application form simulation (apply.html & apply-licence.html)
    const applyForms = document.querySelectorAll('.panel.form form');
    applyForms.forEach(form => {
      const submitBtn = form.querySelector('.btn-primary');
      if (submitBtn) {
        submitBtn.addEventListener('click', function (e) {
          e.preventDefault();
          const nameInput = form.querySelector('input[placeholder*="name" i]');
          if (nameInput && !nameInput.value.trim()) {
            showToast('Please enter your full name before continuing.', 'error');
            nameInput.focus();
            return;
          }
          submitBtn.disabled = true;
          submitBtn.textContent = 'Submitting...';
          setTimeout(() => {
            showToast('Application submitted successfully! Reference generated.', 'success');
            submitBtn.textContent = 'Submitted ✓';
            setTimeout(() => {
              window.location.href = 'applications.html';
            }, 1200);
          }, 600);
        });
      }
    });
  }

  // --- Global Document Click listener ---
  document.addEventListener('click', function () {
    closeAllDropdowns();
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeAllDropdowns();
    }
  });

  // --- Initialize on DOMContentLoaded ---
  document.addEventListener('DOMContentLoaded', function () {
    updateHeaderProfile();
    initMobileMenu();
    highlightActiveNav();
    initPageInteractions();
  });

  // Expose API to window for auth.js and inline scripts
  window.RTO = {
    getCurrentUser,
    setCurrentUser,
    logoutUser,
    showToast,
    updateHeaderProfile
  };
})();
